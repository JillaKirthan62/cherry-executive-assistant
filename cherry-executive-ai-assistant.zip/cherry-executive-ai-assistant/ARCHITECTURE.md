# Cherry Executive AI Assistant — Code Map

```text
src/
  routes/                 Pages and API endpoints (one file = one URL)
    index.tsx             Landing page  (/)
    auth.tsx              Sign in with Google / GitHub  (/auth)
    reset-password.tsx    Password reset  (/reset-password)
    pricing.tsx           Free plan page  (/pricing)
    _authenticated/       Pages that require sign-in
      route.tsx           Sign-in guard
      chat.tsx            The chatbot  (/chat)
    api/chat.ts           Backend: streaming AI chat endpoint (signed-in users only)
  lib/                    Backend + shared logic
    ai-gateway.ts         AI model connection (server only)
    chat.functions.ts     Chat history: threads + messages (server functions)
    file-extract.server.ts  Reads uploaded text files
    web-search.server.ts  Wikipedia grounding
    live-facts.server.ts  Wikidata live fact checks
    security-headers.ts   CSP / HSTS / security headers
    export-chat.ts        PDF transcript export
    voice.ts              Browser speech input/output
    error-*.ts, utils.ts  Error handling, helpers
  components/
    chat/                 Chat-specific pieces (previews, scan summary)
    ai-elements/          Chat UI building blocks
    ui/                   Basic buttons, inputs, dialogs
  integrations/           Auto-generated sign-in & database clients (do not edit)
supabase/                 Database migrations
public/                   Favicon, robots.txt
```

Required platform files (do not delete): `.env` (public, non-secret connection
values; real secrets are stored securely on the server), `wrangler.jsonc` and
`vite.config.ts` (hosting/build config), `package.json`, `bun.lock`, `tsconfig.json`.
