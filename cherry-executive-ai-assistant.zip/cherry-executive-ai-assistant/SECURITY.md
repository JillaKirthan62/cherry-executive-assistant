# Security Overview — Cherry Executive AI Assistant

Last reviewed: 2026-08-03

This document summarises the current security posture of the application, based
on the latest automated scan and the controls implemented in the codebase. It is
maintained by the app owner and is not an independent audit or certification.

## Scan summary

Latest automated scan results: **no open findings.**

| Scanner | Scope | Open findings |
| --- | --- | --- |
| Supply chain | npm dependency advisories | 0 |
| Backend / database | RLS policies, exposed data, misconfiguration | 0 |
| Application code | secrets, injection, unsafe rendering | 0 |
| Connectors / integrations | external credential usage | 0 |

## Issues found and resolved

| Area | Issue | Resolution |
| --- | --- | --- |
| Dependencies | Critical advisory in the transitive `seroval` package (deserialization type confusion) reachable via the router/start packages | Pinned `seroval` and `seroval-plugins` to `^1.6.0` through package overrides and regenerated the lockfile |
| AI output rendering | Model-generated Markdown was converted to HTML and injected into the DOM, allowing script injection through crafted output | Output is sanitised with DOMPurify before rendering |
| Chat API validation | Request schema accepted unknown fields, and the assistant role could be supplied by the caller | Zod schemas are `.strict()`; only `user` and `assistant` roles are accepted, blocking system-prompt injection |
| Error handling | Upstream provider error details were returned to the browser | Detailed errors are logged server-side with a trace ID; clients receive a generic message |
| Request abuse | Unbounded chat payloads | Enforced limits: 50 messages, 10,000 characters per message, 256 KB request body |

## Implemented controls

- **Authentication** — email/password and Google sign-in via Lovable Cloud auth. The chat experience lives behind an authenticated route layout; unauthenticated visitors are redirected to `/auth`.
- **Data isolation** — chat threads and messages are stored per user with row level security; access is scoped to the authenticated user id.
- **Secrets handling** — provider API keys are read only inside server handlers from the server runtime environment. No private keys are shipped to the browser.
- **Input validation** — all chat requests are validated with strict Zod schemas and size limits before any model call.
- **Output sanitisation** — assistant Markdown is sanitised before being rendered as HTML.
- **Resilience** — server-side circuit breaker, retry with backoff, model fallback, and trace IDs for every request.
- **Transport and browser hardening** — security response headers applied to every response (see below).

## HTTP security headers

Applied in `src/lib/security-headers.ts` and attached to every Worker response
in `src/server.ts`.

| Header | Value / purpose |
| --- | --- |
| `Content-Security-Policy` | Restricts script, style, frame, object and form targets to the app's own origin plus trusted HTTPS sources; blocks plugin content and framing by third parties. |
| `Strict-Transport-Security` | `max-age=63072000; includeSubDomains; preload` — forces HTTPS for two years. |
| `X-Content-Type-Options` | `nosniff` — prevents MIME type sniffing. |
| `X-Frame-Options` | `SAMEORIGIN` — legacy clickjacking protection alongside `frame-ancestors`. |
| `Referrer-Policy` | `strict-origin-when-cross-origin` — limits URL leakage to third parties. |
| `Cross-Origin-Opener-Policy` | `same-origin` — isolates the browsing context. |
| `Permissions-Policy` | Denies camera, geolocation, payment and USB; allows microphone only for the app's own origin (voice input). |

The CSP intentionally allows inline scripts and styles: the framework emits an
inline hydration payload and UI components set inline style attributes.
Removing `'unsafe-inline'` would require nonce plumbing through server-side
rendering.

## Accepted risks

- The assistant may produce inaccurate or outdated statements. Responses are advisory only and should be confirmed before high-stakes decisions.
- Voice input and speech output rely on the browser's native speech APIs, so audio handling follows the browser vendor's processing.

## Reporting a vulnerability

Report suspected security issues privately to the project owner (Jilla Kirthan)
rather than opening a public issue. Please include reproduction steps and the
affected URL or endpoint.
