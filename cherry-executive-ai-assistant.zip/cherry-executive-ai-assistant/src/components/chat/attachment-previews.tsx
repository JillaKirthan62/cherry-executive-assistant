import { FileSpreadsheet, FileText, FileType2, Loader2, RotateCcw, X } from "lucide-react";
import { usePromptInputAttachments } from "@/components/ai-elements/prompt-input";
import { Button } from "@/components/ui/button";

export type UploadState = {
  status: "idle" | "reading" | "sending" | "error";
  done: number;
  total: number;
  error?: string;
};

function iconFor(mediaType?: string, filename?: string) {
  const n = (filename ?? "").toLowerCase();
  if (mediaType?.includes("spreadsheet") || /\.(xlsx?|csv|tsv)$/.test(n)) return FileSpreadsheet;
  if (mediaType === "application/pdf" || n.endsWith(".pdf")) return FileType2;
  return FileText;
}

function prettySize(bytes?: number) {
  if (!bytes) return null;
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Preview strip for pending attachments: image thumbnails, document chips,
 * an upload progress bar, and retry on failure.
 */
export function AttachmentPreviews({
  upload,
  onRetry,
}: {
  upload: UploadState;
  onRetry: () => void;
}) {
  const attachments = usePromptInputAttachments();
  const files = attachments.files;
  if (files.length === 0) return null;

  const pct =
    upload.total > 0 ? Math.min(100, Math.round((upload.done / upload.total) * 100)) : 0;

  return (
    <div className="border-b border-border/60 bg-background/40 px-3 py-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          {files.length} attachment{files.length > 1 ? "s" : ""}
        </span>
        <button
          type="button"
          onClick={() => attachments.clear()}
          className="text-[11px] text-muted-foreground transition hover:text-foreground"
        >
          Remove all
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {files.map((f) => {
          const isImage = f.mediaType?.startsWith("image/");
          const Icon = iconFor(f.mediaType, f.filename);
          return (
            <div
              key={f.id}
              className="group relative flex items-center gap-2 rounded-lg border border-border bg-card p-2 pr-7"
            >
              {isImage && f.url ? (
                <img
                  src={f.url}
                  alt={f.filename ?? "attachment preview"}
                  className="h-10 w-10 rounded-md border border-border object-cover"
                />
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-md border border-border bg-background">
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </div>
              )}
              <div className="min-w-0 max-w-[150px]">
                <div className="truncate text-[12.5px] leading-5 text-foreground">
                  {f.filename ?? "file"}
                </div>
                <div className="truncate text-[11px] text-muted-foreground">
                  {prettySize((f as { size?: number }).size) ??
                    (f.mediaType ?? "").split("/").pop() ??
                    "file"}
                </div>
              </div>
              <button
                type="button"
                onClick={() => attachments.remove(f.id)}
                aria-label={`Remove ${f.filename ?? "file"}`}
                className="absolute right-1.5 top-1.5 rounded p-0.5 text-muted-foreground opacity-70 transition hover:bg-accent hover:text-foreground group-hover:opacity-100"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      {(upload.status === "reading" || upload.status === "sending") && (
        <div className="mt-3">
          <div className="mb-1 flex items-center gap-2 text-[11px] text-muted-foreground">
            <Loader2 className="h-3 w-3 animate-spin" />
            {upload.status === "reading"
              ? `Uploading attachments — ${upload.done}/${upload.total}`
              : "Sending to Cherry…"}
          </div>
          <div className="h-1 overflow-hidden rounded-full bg-border">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: upload.status === "sending" ? "100%" : `${pct}%` }}
            />
          </div>
        </div>
      )}

      {upload.status === "error" && (
        <div className="mt-3 flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2">
          <span className="text-[12px] text-destructive">
            {upload.error ?? "Upload failed."}
          </span>
          <Button type="button" size="sm" variant="outline" onClick={onRetry} className="h-7 gap-1.5">
            <RotateCcw className="h-3.5 w-3.5" />
            Retry
          </Button>
        </div>
      )}
    </div>
  );
}
