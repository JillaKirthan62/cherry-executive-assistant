import { useEffect, useMemo, useState } from "react";
import { FileText, RefreshCw, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export type ScanFile = { id: string; name: string; size?: number; text: string };

export type ScanResult = {
  name: string;
  size?: number;
  bullets: string[];
};

function summarize(file: ScanFile): ScanResult {
  const text = file.text;
  const lines = text.split(/\r?\n/);
  const nonEmpty = lines.filter((l) => l.trim().length > 0);
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const looksTabular = /,|\t|;/.test(nonEmpty[0] ?? "") && nonEmpty.length > 1;
  const isJson = /^\s*[[{]/.test(text);
  const headings = nonEmpty.filter((l) => /^#{1,3}\s/.test(l)).slice(0, 3);
  const preview = (nonEmpty[0] ?? "").slice(0, 120);

  const bullets: string[] = [];
  bullets.push(
    `${nonEmpty.length} non-empty line${nonEmpty.length === 1 ? "" : "s"}, ${words} words, ${text.length} characters`,
  );
  if (isJson) bullets.push("Structure: JSON payload detected");
  else if (looksTabular)
    bullets.push(
      `Structure: delimited/tabular data — first row: ${(nonEmpty[0] ?? "").slice(0, 90)}`,
    );
  else bullets.push("Structure: plain prose / notes");
  if (headings.length) bullets.push(`Sections: ${headings.map((h) => h.replace(/^#+\s/, "")).join(" · ")}`);
  if (preview) bullets.push(`Opens with: “${preview}${preview.length >= 120 ? "…" : ""}”`);
  return { name: file.name, size: file.size, bullets };
}

function prettySize(bytes?: number) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Shows the scan of pending text attachments as key-finding bullets, lets the
 * user edit the findings, and re-scan before the final answer is requested.
 */
export function ScanSummary({
  files,
  notes,
  onNotesChange,
  onRescan,
}: {
  files: ScanFile[];
  notes: string | null;
  onNotesChange: (v: string | null) => void;
  onRescan: () => void;
}) {
  const results = useMemo(() => files.map(summarize), [files]);
  const [editing, setEditing] = useState(false);

  const baseline = useMemo(
    () =>
      results
        .map((r) => `${r.name}${r.size ? ` (${prettySize(r.size)})` : ""}\n${r.bullets.map((b) => `• ${b}`).join("\n")}`)
        .join("\n\n"),
    [results],
  );

  useEffect(() => {
    if (!editing) onNotesChange(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseline]);

  if (files.length === 0) return null;

  return (
    <div className="mb-2 rounded-2xl border border-border bg-card/80 p-4 shadow-elegant">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          Scanned file findings
        </div>
        <div className="flex items-center gap-1">
          <Button type="button" variant="ghost" size="sm" className="h-7 gap-1.5" onClick={onRescan}>
            <RefreshCw className="h-3.5 w-3.5" />
            Re-scan
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7"
            onClick={() => {
              if (editing) {
                setEditing(false);
              } else {
                onNotesChange(notes ?? baseline);
                setEditing(true);
              }
            }}
          >
            {editing ? "Done" : "Edit"}
          </Button>
        </div>
      </div>

      {editing ? (
        <textarea
          value={notes ?? baseline}
          onChange={(e) => onNotesChange(e.target.value)}
          rows={Math.min(14, (notes ?? baseline).split("\n").length + 1)}
          className="w-full resize-y rounded-lg border border-border bg-background p-3 text-[13px] leading-6 text-foreground outline-none focus:border-primary/60"
        />
      ) : notes ? (
        <pre className="whitespace-pre-wrap text-[13px] leading-6 text-foreground">{notes}</pre>
      ) : (
        <div className="space-y-3">
          {results.map((r) => (
            <div key={r.name}>
              <div className="mb-1 flex items-center gap-2 text-[13px] font-medium text-foreground">
                <FileText className="h-3.5 w-3.5 text-muted-foreground" />
                {r.name}
                {r.size ? (
                  <span className="text-[11px] text-muted-foreground">{prettySize(r.size)}</span>
                ) : null}
              </div>
              <ul className="ml-5 list-disc space-y-1 text-[13px] leading-6 text-muted-foreground">
                {r.bullets.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      <p className="mt-3 text-[11px] text-muted-foreground">
        Cherry will use these findings — edit or re-scan before sending.
      </p>
    </div>
  );
}
