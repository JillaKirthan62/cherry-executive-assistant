import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

export type PricingPlan = {
  name: string;
  price: string;
  period: string;
  tagline: string;
  features: string[];
  cta: string;
  highlight?: boolean;
};

export const PLANS: PricingPlan[] = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    tagline: "Every Cherry feature, free for everyone.",
    features: [
      "Unlimited chat with the most advanced model",
      "Voice input & spoken replies",
      "Conversation history",
      "Live web facts & deeper reasoning",
      "Longer context for documents & briefs",
      "Text file scanning & summaries",
      "Strategy, writing, analysis & code prompts",
      "New Cherry features as they ship",
    ],
    cta: "Your current plan",
  },
];

export function PricingPlans({
  onChoose,
}: {
  onChoose?: (plan: PricingPlan) => void;
  compact?: boolean;
}) {
  return (
    <div className="mx-auto w-full max-w-md">
      {PLANS.map((plan) => (
        <div
          key={plan.name}
          className="relative flex flex-col rounded-2xl border border-border bg-card p-6"
        >
          <div className="mb-4">
            <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              Cherry {plan.name}
            </div>
            <div className="mt-2 flex items-baseline gap-1.5">
              <span className="font-serif text-4xl leading-none text-foreground">
                {plan.price}
              </span>
              <span className="text-[12px] text-muted-foreground">
                / {plan.period}
              </span>
            </div>
            <p className="mt-2 text-[13.5px] leading-6 text-muted-foreground">
              {plan.tagline}
            </p>
          </div>

          <ul className="mb-6 space-y-2.5">
            {plan.features.map((f) => (
              <li
                key={f}
                className="flex items-start gap-2 text-[13.5px] leading-6 text-foreground"
              >
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <span>{f}</span>
              </li>
            ))}
          </ul>

          <Button
            type="button"
            onClick={() => onChoose?.(plan)}
            disabled
            className="mt-auto h-10 w-full rounded-lg bg-secondary text-[13px] font-medium text-secondary-foreground hover:bg-secondary/80"
          >
            {plan.cta}
          </Button>
        </div>
      ))}
    </div>
  );
}
