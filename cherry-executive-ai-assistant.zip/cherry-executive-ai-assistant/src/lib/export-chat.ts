import type { UIMessage } from "ai";

type ExportMeta = { title: string; exportedAt?: string };

function plainText(m: UIMessage) {
  return (m.parts ?? [])
    .map((p) => (p.type === "text" ? p.text : p.type === "file" ? `[file: ${(p as { filename?: string }).filename ?? "attachment"}]` : ""))
    .join("\n")
    .trim();
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function slug(s: string) {
  return (s || "cherry-chat").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48) || "cherry-chat";
}

export function exportChatAsJson(messages: UIMessage[], meta: ExportMeta) {
  const payload = {
    app: "Cherry Executive AI Assistant",
    title: meta.title,
    exportedAt: meta.exportedAt ?? new Date().toISOString(),
    messageCount: messages.length,
    messages: messages.map((m) => ({ id: m.id, role: m.role, text: plainText(m), parts: m.parts })),
  };
  download(
    new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }),
    `${slug(meta.title)}-transcript.json`,
  );
}

function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * Opens a print-ready transcript; the browser's print dialog saves it as PDF.
 */
export function exportChatAsPdf(messages: UIMessage[], meta: ExportMeta) {
  const rows = messages
    .map((m) => {
      const who = m.role === "user" ? "You" : "Cherry";
      const body = escapeHtml(plainText(m)).replace(/\n/g, "<br/>");
      return `<article class="${m.role}"><h2>${who}</h2><p>${body}</p></article>`;
    })
    .join("");

  const html = `<!doctype html><html><head><meta charset="utf-8"/>
<title>${escapeHtml(meta.title)} — Cherry transcript</title>
<style>
  @page { margin: 18mm; }
  body { font: 12.5px/1.7 Georgia, "Times New Roman", serif; color: #16161a; }
  header { border-bottom: 1px solid #ddd; padding-bottom: 10px; margin-bottom: 18px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .meta { font: 10px/1.5 Arial, sans-serif; text-transform: uppercase; letter-spacing: .12em; color: #777; }
  article { margin: 0 0 14px; page-break-inside: avoid; }
  article h2 { font: 10px/1.4 Arial, sans-serif; text-transform: uppercase; letter-spacing: .14em; color: #9b1c31; margin: 0 0 4px; }
  article.user h2 { color: #555; }
  article p { margin: 0; }
  footer { margin-top: 24px; border-top: 1px solid #ddd; padding-top: 8px; font: 10px Arial, sans-serif; color: #888; }
</style></head><body>
<header><h1>${escapeHtml(meta.title)}</h1>
<div class="meta">Cherry Executive AI Assistant · ${new Date().toLocaleString()}</div></header>
${rows}
<footer>Exported from Cherry — ${messages.length} messages.</footer>
<script>window.onload = function(){ window.focus(); window.print(); };</script>
</body></html>`;

  const w = window.open("", "_blank", "width=880,height=1000");
  if (!w) {
    // Popup blocked — fall back to downloading the printable file.
    download(new Blob([html], { type: "text/html" }), `${slug(meta.title)}-transcript.html`);
    return false;
  }
  w.document.write(html);
  w.document.close();
  return true;
}
