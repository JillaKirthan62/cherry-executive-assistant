// Server-only helpers for extracting text from uploaded documents.
import mammoth from "mammoth";
import * as XLSX from "xlsx";

export type FileAttachment = {
  name: string;
  mediaType: string;
  url: string; // data URL
};

export function decodeDataUrl(dataUrl: string): { mime: string; bytes: Uint8Array } | null {
  if (!dataUrl.startsWith("data:")) return null;
  const commaIdx = dataUrl.indexOf(",");
  if (commaIdx === -1) return null;
  const header = dataUrl.slice(5, commaIdx);
  const payload = dataUrl.slice(commaIdx + 1);
  const isBase64 = header.endsWith(";base64");
  const mime = (isBase64 ? header.slice(0, -7) : header) || "application/octet-stream";
  try {
    if (isBase64) {
      const buf = Buffer.from(payload, "base64");
      return { mime, bytes: new Uint8Array(buf) };
    }
    return { mime, bytes: new TextEncoder().encode(decodeURIComponent(payload)) };
  } catch {
    return null;
  }
}

export function isImage(mime: string, name: string) {
  return mime.startsWith("image/") || /\.(png|jpe?g|webp|gif)$/i.test(name);
}

export function isPdf(mime: string, name: string) {
  return mime === "application/pdf" || /\.pdf$/i.test(name);
}

export async function extractTextFromFile(
  mime: string,
  name: string,
  bytes: Uint8Array,
): Promise<string> {
  const lower = name.toLowerCase();
  if (
    mime.startsWith("text/") ||
    /\.(txt|md|csv|tsv|json|log|yaml|yml)$/i.test(lower)
  ) {
    return new TextDecoder("utf-8").decode(bytes);
  }
  if (lower.endsWith(".docx") || mime.includes("wordprocessingml")) {
    const result = await mammoth.extractRawText({
      buffer: Buffer.from(bytes),
    } as { buffer: Buffer });
    return result.value ?? "";
  }
  if (
    lower.endsWith(".xlsx") ||
    lower.endsWith(".xls") ||
    mime.includes("spreadsheetml") ||
    mime.includes("ms-excel")
  ) {
    const wb = XLSX.read(bytes, { type: "array" });
    return wb.SheetNames.map(
      (n) => `--- Sheet: ${n} ---\n${XLSX.utils.sheet_to_csv(wb.Sheets[n])}`,
    ).join("\n\n");
  }
  return "";
}
