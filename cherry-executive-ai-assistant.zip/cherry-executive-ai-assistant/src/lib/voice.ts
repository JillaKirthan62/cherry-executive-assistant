import { useCallback, useEffect, useRef, useState } from "react";

// Minimal types for the Web Speech API (not in lib.dom for TS).
type SRConstructor = new () => SpeechRecognitionLike;
interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: { error?: string }) => void) | null;
  onend: (() => void) | null;
}
interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<{
    0: { transcript: string };
    isFinal: boolean;
    length: number;
  }>;
}

function getSR(): SRConstructor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: SRConstructor;
    webkitSpeechRecognition?: SRConstructor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function isSpeechRecognitionSupported() {
  return getSR() !== null;
}

export function useSpeechRecognition({
  onFinal,
  onInterim,
  onError,
}: {
  onFinal: (text: string) => void;
  onInterim?: (text: string) => void;
  onError?: (code: string, message: string) => void;
}) {
  const [listening, setListening] = useState(false);
  const recRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    return () => {
      recRef.current?.abort();
      recRef.current = null;
    };
  }, []);

  const start = useCallback(async () => {
    const SR = getSR();
    if (!SR) {
      onError?.("unsupported", "Voice input isn't supported in this browser. Try Chrome or Edge.");
      return false;
    }

    // Proactively request/verify microphone permission so onend doesn't
    // fire silently right after start (the classic "clicks then stops" bug).
    try {
      if (navigator.mediaDevices?.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        // Immediately release — SpeechRecognition manages its own stream.
        stream.getTracks().forEach((t) => t.stop());
      }
    } catch (err) {
      const name = (err as { name?: string } | null)?.name ?? "";
      if (name === "NotAllowedError" || name === "SecurityError") {
        onError?.("not-allowed", "Microphone blocked. Allow mic access in your browser's site settings, then try again.");
      } else if (name === "NotFoundError" || name === "OverconstrainedError") {
        onError?.("no-device", "No microphone was found on this device.");
      } else if (name === "NotReadableError") {
        onError?.("in-use", "Your microphone is being used by another app. Close it and try again.");
      } else {
        onError?.("mic-error", "Couldn't access the microphone.");
      }
      return false;
    }

    if (recRef.current) recRef.current.abort();

    const rec = new SR();
    rec.lang = navigator.language || "en-US";
    rec.continuous = false;
    rec.interimResults = true;

    let finalText = "";
    let sawResult = false;
    let hardError: string | null = null;

    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        const txt = r[0].transcript;
        if (r.isFinal) finalText += txt;
        else interim += txt;
        sawResult = true;
      }
      if (interim && onInterim) onInterim(interim);
    };
    rec.onerror = (e) => {
      hardError = e.error ?? "unknown";
      setListening(false);
      if (hardError === "not-allowed" || hardError === "service-not-allowed") {
        onError?.("not-allowed", "Microphone blocked. Allow mic access in your browser's site settings.");
      } else if (hardError === "no-speech") {
        onError?.("no-speech", "I didn't catch that — try speaking again.");
      } else if (hardError === "audio-capture") {
        onError?.("no-device", "No microphone was found on this device.");
      } else if (hardError === "network") {
        onError?.("network", "Speech service unreachable. Check your connection.");
      } else if (hardError !== "aborted") {
        onError?.(hardError, `Voice input failed (${hardError}).`);
      }
    };
    rec.onend = () => {
      setListening(false);
      const text = finalText.trim();
      if (text) onFinal(text);
      else if (!sawResult && !hardError) onError?.("no-speech", "I didn't catch that — try speaking again.");
    };

    try {
      rec.start();
      recRef.current = rec;
      setListening(true);
      return true;
    } catch (err) {
      setListening(false);
      const msg = err instanceof Error ? err.message : String(err);
      onError?.("start-failed", msg || "Couldn't start voice input.");
      return false;
    }
  }, [onFinal, onInterim, onError]);


  const stop = useCallback(() => {
    recRef.current?.stop();
  }, []);

  return { listening, start, stop };
}

// ---- Text-to-Speech (browser SpeechSynthesis) ----

export function isSpeechSynthesisSupported() {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

function pickVoice(): SpeechSynthesisVoice | null {
  if (!isSpeechSynthesisSupported()) return null;
  const voices = window.speechSynthesis.getVoices();
  if (voices.length === 0) return null;
  const preferred = [
    "Google UK English Female",
    "Microsoft Aria Online (Natural)",
    "Samantha",
    "Karen",
    "Google US English",
  ];
  for (const name of preferred) {
    const v = voices.find((v) => v.name === name);
    if (v) return v;
  }
  return (
    voices.find((v) => v.lang?.startsWith("en") && /female/i.test(v.name)) ??
    voices.find((v) => v.lang?.startsWith("en")) ??
    voices[0]
  );
}

export function speak(text: string, opts?: { onEnd?: () => void }) {
  if (!isSpeechSynthesisSupported() || !text.trim()) {
    opts?.onEnd?.();
    return;
  }
  const synth = window.speechSynthesis;
  synth.cancel();
  // strip markdown noise for cleaner speech
  const clean = text
    .replace(/```[\s\S]*?```/g, " code block ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/[*_#>~]/g, "")
    .replace(/\[(.*?)\]\((.*?)\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) {
    opts?.onEnd?.();
    return;
  }
  const utter = new SpeechSynthesisUtterance(clean);
  const voice = pickVoice();
  if (voice) utter.voice = voice;
  utter.rate = 1.02;
  utter.pitch = 1.05;
  if (opts?.onEnd) utter.onend = () => opts.onEnd?.();
  synth.speak(utter);
}

const FOLLOWUPS = [
  "Would you like a deeper explanation, or shall I explore related questions?",
  "Want me to go further, or pivot to something related?",
  "Shall I expand on this, or take it in a different direction?",
];

export function speakWithFollowup(text: string) {
  speak(text, {
    onEnd: () => {
      const f = FOLLOWUPS[Math.floor(Math.random() * FOLLOWUPS.length)];
      speak(f);
    },
  });
}


export function cancelSpeech() {
  if (isSpeechSynthesisSupported()) window.speechSynthesis.cancel();
}
