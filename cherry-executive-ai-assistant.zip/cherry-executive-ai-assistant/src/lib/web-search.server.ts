// Lightweight, key-less grounding: Wikipedia REST + DuckDuckGo Instant Answer.
// Returns a short block of factual context to inject into the system prompt,
// plus a normalized list of sources for the UI. Includes a small in-memory
// TTL cache to reduce repeated external calls for the same query.

import type { UIMessage } from "ai";

const UA = "CherryAI/1.0 (grounding)";
const MAX_SNIPPET = 900;
const MAX_TOTAL = 2800;

const CURRENT_HINTS = [
  "current", "today", "latest", "now ", "this week", "this month", "this year",
  "recent", "news", "2024", "2025", "2026", "2027",
  "who is ", "who's ", "what is happening", "score", "price of",
  "weather", "election", "won ", "winner", "champion",
];

export type GroundingSource = { title: string; url: string; provider: string };
export type GroundingResult = { context: string; sources: GroundingSource[] };

// --- Tiny TTL cache -------------------------------------------------------
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes
const CACHE_MAX = 200;
const cache = new Map<string, { at: number; value: GroundingResult }>();

function cacheGet(key: string): GroundingResult | null {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > CACHE_TTL_MS) {
    cache.delete(key);
    return null;
  }
  // refresh LRU order
  cache.delete(key);
  cache.set(key, hit);
  return hit.value;
}
function cacheSet(key: string, value: GroundingResult) {
  cache.set(key, { at: Date.now(), value });
  if (cache.size > CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest) cache.delete(oldest);
  }
}

function getLatestUserText(messages: UIMessage[]): string {
  const last = [...messages].reverse().find((m) => m.role === "user");
  return (
    last?.parts?.map((p) => (p.type === "text" ? p.text : "")).join(" ").trim() ?? ""
  );
}

function needsGrounding(text: string): boolean {
  const t = text.toLowerCase();
  if (t.length < 3 || t.length > 400) return false;
  return CURRENT_HINTS.some((k) => t.includes(k));
}

async function fetchJson<T>(url: string, timeoutMs = 4000): Promise<T | null> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": UA, Accept: "application/json" },
      signal: ctrl.signal,
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function duckDuckGo(
  query: string,
): Promise<{ text: string; sources: GroundingSource[] } | null> {
  const url =
    "https://api.duckduckgo.com/?" +
    new URLSearchParams({ q: query, format: "json", no_html: "1", skip_disambig: "1" });
  type DDG = {
    AbstractText?: string;
    AbstractSource?: string;
    AbstractURL?: string;
    Answer?: string;
    Definition?: string;
    Heading?: string;
    RelatedTopics?: Array<{ Text?: string; FirstURL?: string }>;
  };
  const data = await fetchJson<DDG>(url);
  if (!data) return null;
  const chunks: string[] = [];
  const sources: GroundingSource[] = [];
  if (data.Answer) chunks.push(`Answer: ${data.Answer}`);
  if (data.AbstractText) {
    const src = data.AbstractSource ? ` (${data.AbstractSource})` : "";
    chunks.push(`${data.AbstractText.slice(0, MAX_SNIPPET)}${src}`);
  } else if (data.Definition) {
    chunks.push(data.Definition.slice(0, MAX_SNIPPET));
  }
  if (data.AbstractURL) {
    sources.push({
      title: data.Heading || data.AbstractSource || "DuckDuckGo",
      url: data.AbstractURL,
      provider: "DuckDuckGo",
    });
  }
  const related = (data.RelatedTopics ?? []).filter((r) => r?.FirstURL && r?.Text).slice(0, 3);
  for (const r of related) {
    if (r.FirstURL && r.Text) {
      sources.push({ title: r.Text.slice(0, 90), url: r.FirstURL, provider: "DuckDuckGo" });
    }
  }
  const combined = chunks.join("\n");
  if (!combined.trim() && sources.length === 0) return null;
  const url2 = data.AbstractURL ? `\nSource: ${data.AbstractURL}` : "";
  return { text: `[DuckDuckGo]\n${combined}${url2}`, sources };
}

async function wikipediaSummary(
  query: string,
): Promise<{ text: string; sources: GroundingSource[] } | null> {
  const searchUrl =
    "https://en.wikipedia.org/w/api.php?" +
    new URLSearchParams({
      action: "query",
      list: "search",
      srsearch: query,
      srlimit: "1",
      format: "json",
      origin: "*",
    });
  type Search = { query?: { search?: Array<{ title?: string }> } };
  const s = await fetchJson<Search>(searchUrl);
  const title = s?.query?.search?.[0]?.title;
  if (!title) return null;

  const sumUrl =
    "https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(title);
  type Sum = { extract?: string; content_urls?: { desktop?: { page?: string } } };
  const sum = await fetchJson<Sum>(sumUrl);
  const extract = sum?.extract?.slice(0, MAX_SNIPPET);
  if (!extract) return null;
  const src =
    sum?.content_urls?.desktop?.page ??
    `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`;
  return {
    text: `[Wikipedia: ${title}]\n${extract}\nSource: ${src}`,
    sources: [{ title: `Wikipedia: ${title}`, url: src, provider: "Wikipedia" }],
  };
}

export async function buildWebSearchGrounding(messages: UIMessage[]): Promise<GroundingResult> {
  const query = getLatestUserText(messages);
  const empty: GroundingResult = { context: "", sources: [] };
  if (!query || !needsGrounding(query)) return empty;

  const key = query.toLowerCase().replace(/\s+/g, " ").trim();
  const cached = cacheGet(key);
  if (cached) return cached;

  const [ddg, wiki] = await Promise.all([duckDuckGo(query), wikipediaSummary(query)]);
  const parts = [ddg, wiki].filter((v): v is { text: string; sources: GroundingSource[] } => Boolean(v));
  if (parts.length === 0) {
    cacheSet(key, empty);
    return empty;
  }

  // De-dupe sources by URL
  const seen = new Set<string>();
  const sources: GroundingSource[] = [];
  for (const p of parts) {
    for (const s of p.sources) {
      if (seen.has(s.url)) continue;
      seen.add(s.url);
      sources.push(s);
    }
  }

  const asOf = new Date().toISOString();
  const body = parts.map((p) => p.text).join("\n\n").slice(0, MAX_TOTAL);
  const context =
    `\n\nWEB CONTEXT — fetched at ${asOf} for grounding the user's latest question:\n` +
    body +
    `\nInstruction: When these sources answer the user's question, prefer them over older training data and cite the source URL inline.`;
  const value: GroundingResult = { context, sources };
  cacheSet(key, value);
  return value;
}

// Backwards-compatible helper (context only).
export async function buildWebSearchContext(messages: UIMessage[]): Promise<string> {
  return (await buildWebSearchGrounding(messages)).context;
}
