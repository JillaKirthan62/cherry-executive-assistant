import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { LogOut } from "lucide-react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  ArrowUpRight,
  History,
  Mic,
  MicOff,
  Paperclip,
  Plus,
  Sparkles,
  Square,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import cherryLogo from "@/assets/cherry-logo.png";
import { PricingPlans } from "@/components/pricing-plans";
import { AttachmentPreviews, type UploadState } from "@/components/chat/attachment-previews";
import { exportChatAsPdf } from "@/lib/export-chat";
import { ScanSummary, type ScanFile } from "@/components/chat/scan-summary";
import { Download } from "lucide-react";

import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputBody,
  PromptInputTextarea,
  PromptInputFooter,
  usePromptInputAttachments,
  type PromptInputMessage,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";

function AttachButton() {
  const attachments = usePromptInputAttachments();
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon-sm"
      onClick={() => attachments.openFileDialog()}
      title="Attach files"
      className="text-muted-foreground hover:text-foreground"
    >
      <Paperclip className="h-4 w-4" />
    </Button>
  );
}
function AttachmentWatcher({ onChange }: { onChange: (files: { id: string; filename?: string; url?: string; size?: number }[]) => void }) {
  const attachments = usePromptInputAttachments();
  const files = attachments.files;
  const signature = files.map((f) => `${f.id}:${f.url ?? ""}`).join("|");
  const lastRef = useRef("");
  useEffect(() => {
    if (lastRef.current === signature) return;
    lastRef.current = signature;
    onChange(
      files.map((f) => ({
        id: f.id,
        filename: f.filename,
        url: f.url,
        size: (f as { size?: number }).size,
      })),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signature]);
  return null;
}

import { Button } from "@/components/ui/button";
import {
  cancelSpeech,
  isSpeechRecognitionSupported,
  isSpeechSynthesisSupported,
  speak,
  speakWithFollowup,
  useSpeechRecognition,
} from "@/lib/voice";
import {
  createThread,
  deleteThread,
  getThreadMessages,
  listThreads,
  clearAllThreads,
} from "@/lib/chat.functions";

type SearchParams = { t?: string };

export const Route = createFileRoute("/_authenticated/chat")({
  validateSearch: (s: Record<string, unknown>): SearchParams => ({
    t: typeof s.t === "string" ? s.t : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Cherry — Executive AI Assistant" },
      {
        name: "description",
        content:
          "Cherry is a precise, executive-grade AI assistant. Strategy, writing, code, and clear answers — on demand.",
      },
      { property: "og:title", content: "Cherry — Executive AI Assistant" },
      {
        property: "og:description",
        content: "Precise answers, executive tone. Built for serious work.",
      },
    ],
  }),
  component: ChatPage,
});

const CAPABILITIES = [
  { label: "Strategy", prompt: "Give me an executive briefing on the current state of AI infrastructure, in 5 bullet points." },
  { label: "Writing", prompt: "Draft a concise board-level memo announcing a product delay, taking responsibility without panic." },
  { label: "Analysis", prompt: "Compare the leadership styles of Sundar Pichai and Elon Musk in 6 lines." },
  { label: "Code", prompt: "Write a production-grade TypeScript function for debouncing async calls with cancellation." },
];

type ThreadRow = { id: string; title: string; updated_at: string; created_at: string };
type MessageRow = { id: string; role: string; parts: unknown; created_at: string };
type GroundingSource = { title: string; url: string; provider: string };
type GroundingPayload = { used: boolean; sources: GroundingSource[] };

const MAX_FILE_MB = 5;
const MAX_FILE_BYTES = MAX_FILE_MB * 1024 * 1024;

const ACCEPT = [
  "text/plain", "text/markdown", "text/csv", "text/tab-separated-values",
  "application/json",
  ".txt", ".md", ".csv", ".tsv", ".json", ".log", ".yaml", ".yml",
].join(",");


function ChatPage() {
  const navigate = useNavigate();
  const search = useSearch({ from: Route.id });
  const activeThreadId = search.t;

  const listThreadsFn = useServerFn(listThreads);
  const createThreadFn = useServerFn(createThread);
  const deleteThreadFn = useServerFn(deleteThread);
  const clearAllThreadsFn = useServerFn(clearAllThreads);
  const getThreadMessagesFn = useServerFn(getThreadMessages);

  const [threads, setThreads] = useState<ThreadRow[]>([]);
  const [initialMessages, setInitialMessages] = useState<UIMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [pricingOpen, setPricingOpen] = useState(false);
  const [input, setInput] = useState("");
  const [upload, setUpload] = useState<UploadState>({ status: "idle", done: 0, total: 0 });
  const [dragging, setDragging] = useState(false);
  const [booting, setBooting] = useState(true);
  const [pending, setPending] = useState<{ id: string; filename?: string; url?: string; size?: number }[]>([]);
  const [scanFiles, setScanFiles] = useState<ScanFile[]>([]);
  const [scanNotes, setScanNotes] = useState<string | null>(null);
  const [scanNonce, setScanNonce] = useState(0);
  const lastSendRef = useRef<{ text: string; files: PromptInputMessage["files"] } | null>(null);
  const [voiceOut, setVoiceOut] = useState(false);
  const lastSpokenIdRef = useRef<string | null>(null);
  const voiceTurnRef = useRef(false);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const sttSupported = isSpeechRecognitionSupported();
  const ttsSupported = isSpeechSynthesisSupported();
  const signedOutRef = useRef(false);


  useEffect(() => {
    const t = setTimeout(() => setBooting(false), 1100);
    return () => clearTimeout(t);
  }, []);

  // Scan pending text attachments client-side so findings can be reviewed
  // before the assistant answers.
  useEffect(() => {
    let cancelled = false;
    if (pending.length === 0) {
      setScanFiles([]);
      setScanNotes(null);
      return;
    }
    (async () => {
      const out: ScanFile[] = [];
      for (const f of pending) {
        if (!f.url) continue;
        try {
          const res = await fetch(f.url);
          const text = await res.text();
          out.push({ id: f.id, name: f.filename ?? "file", size: f.size, text });
        } catch {
          /* ignore unreadable file; upload flow reports it */
        }
      }
      if (!cancelled) setScanFiles(out);
    })();
    return () => {
      cancelled = true;
    };
  }, [pending, scanNonce]);

  const handleLogout = async () => {
    signedOutRef.current = true;
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  const refreshThreads = useCallback(async () => {
    if (signedOutRef.current) return [] as ThreadRow[];
    const { data } = await supabase.auth.getSession();
    if (!data.session) return [] as ThreadRow[];
    try {
      const rows = await listThreadsFn();
      setThreads(rows as ThreadRow[]);
      return rows as ThreadRow[];
    } catch {
      return [] as ThreadRow[];
    }
  }, [listThreadsFn]);


  // Ensure we always have an active thread
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const rows = await refreshThreads();
      if (cancelled) return;
      if (!activeThreadId) {
        const first = rows[0];
        if (first) {
          navigate({ to: "/chat", search: { t: first.id }, replace: true });
        } else {
          const created = await createThreadFn({ data: {} });
          if (cancelled) return;
          navigate({ to: "/chat", search: { t: (created as ThreadRow).id }, replace: true });
          await refreshThreads();
        }
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeThreadId]);

  // Load messages for the active thread
  useEffect(() => {
    if (!activeThreadId) {
      setInitialMessages([]);
      return;
    }
    let cancelled = false;
    setLoadingMessages(true);
    (async () => {
      try {
        const rows = (await getThreadMessagesFn({ data: { threadId: activeThreadId } })) as MessageRow[];
        if (cancelled) return;
        const restored: UIMessage[] = rows.map((r) => ({
          id: r.id,
          role: r.role as "user" | "assistant" | "system",
          parts: (Array.isArray(r.parts) ? r.parts : []) as UIMessage["parts"],
        }));
        setInitialMessages(restored);
      } catch (e) {
        console.error(e);
      } finally {
        if (!cancelled) setLoadingMessages(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeThreadId, getThreadMessagesFn]);

  const useFallbackRef = useRef(false);
  const lastUserTextRef = useRef<string>("");
  const lastAssistantIdRef = useRef<string | null>(null);
  // Grounding info captured from the most recent /api/chat response,
  // then attached to the assistant message once it arrives.
  const pendingGroundingRef = useRef<GroundingPayload | null>(null);
  const [groundingByMsgId, setGroundingByMsgId] = useState<Record<string, GroundingPayload>>({});
  // Client-side streaming timeout (aborts if no first byte within N seconds
  // AND if the total stream exceeds a hard cap). This unblocks the UI and
  // lets our onError → fallback-model retry kick in reliably.
  const STREAM_FIRST_BYTE_MS = 20_000;
  const STREAM_HARD_TIMEOUT_MS = 90_000;

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        fetch: async (url, init) => {
          const { data } = await supabase.auth.getSession();
          const token = data.session?.access_token;
          const headers = new Headers(init?.headers);
          if (token) headers.set("Authorization", `Bearer ${token}`);
          let body = init?.body;
          if (typeof body === "string" && useFallbackRef.current) {
            try {
              const parsed = JSON.parse(body);
              parsed.useFallback = true;
              body = JSON.stringify(parsed);
            } catch {
              /* ignore */
            }
          }

          // Compose an AbortController that respects the caller's signal AND
          // our own two-tier timeout (first-byte + hard cap).
          const outerSignal = init?.signal as AbortSignal | undefined;
          const ctrl = new AbortController();
          const abortWith = (reason: string) => {
            if (!ctrl.signal.aborted) {
              console.warn("[chat] aborting stream:", reason);
              ctrl.abort(new DOMException(reason, "AbortError"));
            }
          };
          if (outerSignal) {
            if (outerSignal.aborted) abortWith("caller-aborted");
            else outerSignal.addEventListener("abort", () => abortWith("caller-aborted"), { once: true });
          }
          const firstByteTimer = setTimeout(() => abortWith("first-byte-timeout"), STREAM_FIRST_BYTE_MS);
          const hardTimer = setTimeout(() => abortWith("hard-timeout"), STREAM_HARD_TIMEOUT_MS);

          try {
            const res = await fetch(url as string, { ...init, headers, body, signal: ctrl.signal });
            clearTimeout(firstByteTimer);

            if (res.status === 429) {
              toast.error(
                "Rate limit reached — too many requests in a short window. Wait about a minute, then send again.",
              );
            } else if (res.status === 402 || res.status === 403) {
              toast.error(
                "AI usage quota exhausted for this workspace. Add credits or upgrade your plan to continue.",
              );
            } else if (res.status === 413) {
              toast.error("That message or attachment is too large. Trim it and try again.");
            } else if (res.status >= 500) {
              toast.error("Cherry's AI service returned an error. Retrying may help.");
            }

            const traceId = res.headers.get("X-Trace-Id");
            const breaker = res.headers.get("X-Circuit-Breaker");
            if (traceId) console.log("[chat] trace-id:", traceId, "useFallback:", useFallbackRef.current, "breaker:", breaker);
            if (breaker === "open") {
              toast.error("Cherry's AI service is temporarily unavailable. Please retry in a minute.");
            }
            const groundingRaw = res.headers.get("X-Grounding");
            if (groundingRaw) {
              try {
                const decoded = JSON.parse(atob(groundingRaw)) as GroundingPayload;
                if (decoded?.used && decoded.sources?.length) {
                  pendingGroundingRef.current = decoded;
                }
              } catch {
                /* ignore malformed header */
              }
            }
            // Wrap the body stream so we can clear the hard timer on close.
            if (res.body) {
              const reader = res.body.getReader();
              const stream = new ReadableStream({
                async pull(controller) {
                  try {
                    const { value, done } = await reader.read();
                    if (done) {
                      clearTimeout(hardTimer);
                      controller.close();
                      return;
                    }
                    controller.enqueue(value);
                  } catch (e) {
                    clearTimeout(hardTimer);
                    controller.error(e);
                  }
                },
                cancel(reason) {
                  clearTimeout(hardTimer);
                  reader.cancel(reason);
                },
              });
              return new Response(stream, { status: res.status, statusText: res.statusText, headers: res.headers });
            }
            clearTimeout(hardTimer);
            return res;
          } catch (e) {
            clearTimeout(firstByteTimer);
            clearTimeout(hardTimer);
            throw e;
          }
        },
        body: { threadId: activeThreadId },
      }),
    [activeThreadId],
  );

  const { messages, sendMessage, status, stop, setMessages } = useChat({
    id: activeThreadId ?? "cherry-pending",
    messages: initialMessages,
    transport,
    onError: (err) => {
      console.error(err);
      const msg = err instanceof Error ? err.message : String(err);
      // Auto-retry once with fallback model on transient failure
      if (!useFallbackRef.current && lastUserTextRef.current) {
        useFallbackRef.current = true;
        toast.message("Retrying with backup model…");
        const text = lastUserTextRef.current;
        setTimeout(() => {
          void sendMessage({ text });
        }, 400);
        return;
      }
      useFallbackRef.current = false;
      toast.error(
        msg.includes("Unauthorized") || msg.includes("401")
          ? "Cherry endpoint isn't authorized. Please sign in again."
          : "Couldn't reach Cherry. Please try again.",
      );
    },
  });


  const isBusy = status === "submitted" || status === "streaming";

  // When initialMessages change (thread switch), sync into useChat and
  // rehydrate any persisted grounding parts.
  useEffect(() => {
    setMessages(initialMessages);
    lastSpokenIdRef.current = null;
    const hydrated: Record<string, GroundingPayload> = {};
    for (const m of initialMessages) {
      if (m.role !== "assistant") continue;
      for (const p of m.parts ?? []) {
        const anyP = p as unknown as { type: string; data?: GroundingPayload };
        if (anyP.type === "data-grounding" && anyP.data?.used) {
          hydrated[m.id] = anyP.data;
        }
      }
    }
    setGroundingByMsgId(hydrated);
  }, [initialMessages, setMessages]);

  // When a new assistant message appears, tag it with the pending grounding info.
  useEffect(() => {
    if (!pendingGroundingRef.current) return;
    const last = messages[messages.length - 1];
    if (!last || last.role !== "assistant") return;
    if (lastAssistantIdRef.current === last.id) return;
    lastAssistantIdRef.current = last.id;
    setGroundingByMsgId((prev) => ({ ...prev, [last.id]: pendingGroundingRef.current! }));
    if (status === "ready") pendingGroundingRef.current = null;
  }, [messages, status]);

  useEffect(() => {
    textareaRef.current?.focus();
  }, [activeThreadId, status]);

  // Refresh thread list when a new assistant message finishes; reset fallback flag
  useEffect(() => {
    if (status === "ready" && messages.length > 0) {
      useFallbackRef.current = false;
      void refreshThreads();
    }
  }, [status, messages.length, refreshThreads]);


  useEffect(() => {
    if (status !== "ready") return;
    const last = messages[messages.length - 1];
    if (!last || last.role !== "assistant") return;
    if (lastSpokenIdRef.current === last.id) return;
    const text = last.parts
      .map((p) => (p.type === "text" ? p.text : ""))
      .join(" ")
      .trim();
    if (!text) return;
    lastSpokenIdRef.current = last.id;
    if (voiceTurnRef.current) {
      voiceTurnRef.current = false;
      speakWithFollowup(text);
    } else if (voiceOut) {
      speak(text);
    }
  }, [voiceOut, status, messages]);

  useEffect(() => {
    if (!voiceOut) cancelSpeech();
    return () => cancelSpeech();
  }, [voiceOut]);

  const handleVoiceFinal = useCallback(
    (text: string) => {
      if (!text || isBusy) return;
      voiceTurnRef.current = true;
      void sendMessage({ text });
      setInput("");
    },
    [isBusy, sendMessage],
  );

  const { listening, start: startListening, stop: stopListening } =
    useSpeechRecognition({
      onFinal: handleVoiceFinal,
      onInterim: (t) => setInput(t),
      onError: (_code, message) => {
        toast.error(message);
      },
    });

  const toggleMic = async () => {
    if (!sttSupported) {
      toast.error("Voice input isn't supported in this browser. Try Chrome or Edge.");
      return;
    }
    if (listening) {
      stopListening();
    } else {
      cancelSpeech();
      await startListening();
    }
  };


  const toggleVoiceOut = () => {
    if (!ttsSupported) {
      toast.error("Voice output isn't supported in this browser.");
      return;
    }
    setVoiceOut((v) => {
      if (v) cancelSpeech();
      return !v;
    });
  };

  const deliver = useCallback(
    async (text: string, files: PromptInputMessage["files"]) => {
      lastUserTextRef.current = text;
      useFallbackRef.current = false;
      try {
        if (files.length > 0) {
          setUpload({ status: "reading", done: 0, total: files.length });
          for (let i = 0; i < files.length; i++) {
            const f = files[i];
            if (!f.url) throw new Error(`Couldn't read "${f.filename ?? "file"}".`);
            // Verify the payload is readable before sending it upstream.
            if (f.url.startsWith("blob:")) {
              const res = await fetch(f.url);
              if (!res.ok) throw new Error(`Couldn't read "${f.filename ?? "file"}".`);
              await res.blob();
            }
            setUpload({ status: "reading", done: i + 1, total: files.length });
          }
          setUpload({ status: "sending", done: files.length, total: files.length });
        }
        const findings = scanNotes?.trim();
        const composed = findings
          ? `${text || "Use the attached file(s)."}\n\n[Reviewed file findings]\n${findings}`
          : text || " ";
        await sendMessage({ text: composed, files: files as never });
        setUpload({ status: "idle", done: 0, total: 0 });
        setInput("");
      } catch (err) {
        const message =
          err instanceof Error ? err.message : "Upload failed — check your connection and retry.";
        setUpload({ status: "error", done: 0, total: files.length, error: message });
        toast.error(message);
      }
    },
    [sendMessage, scanNotes],
  );

  const handleSubmit = useCallback(
    (message: PromptInputMessage) => {
      const text = message.text?.trim() ?? "";
      const files = message.files ?? [];
      if ((!text && files.length === 0) || isBusy) return;
      lastSendRef.current = { text, files };
      void deliver(text, files);
    },
    [isBusy, deliver],
  );

  const retryUpload = useCallback(() => {
    const last = lastSendRef.current;
    if (!last) return;
    void deliver(last.text, last.files);
  }, [deliver]);

  const exportTranscript = () => {
    if (messages.length === 0) {
      toast.error("Nothing to export yet.");
      return;
    }
    const title = threads.find((t) => t.id === activeThreadId)?.title ?? "Cherry conversation";
    const ok = exportChatAsPdf(messages, { title });
    toast.success(ok ? "Print dialog opened — save as PDF." : "Popup blocked — transcript downloaded instead.");
  };

  const sendPrompt = (text: string) => {
    if (isBusy) return;
    lastUserTextRef.current = text;
    useFallbackRef.current = false;
    void sendMessage({ text });
  };


  const newChat = async () => {
    cancelSpeech();
    stopListening();
    setInput("");
    lastSpokenIdRef.current = null;
    try {
      const t = (await createThreadFn({ data: {} })) as ThreadRow;
      await refreshThreads();
      navigate({ to: "/chat", search: { t: t.id } });
      setHistoryOpen(false);
    } catch (e) {
      console.error(e);
      toast.error("Couldn't start a new chat.");
    }
  };

  const openSession = (id: string) => {
    cancelSpeech();
    stopListening();
    lastSpokenIdRef.current = null;
    navigate({ to: "/chat", search: { t: id } });
    setHistoryOpen(false);
  };

  const deleteSession = async (id: string) => {
    try {
      await deleteThreadFn({ data: { id } });
      const rows = await refreshThreads();
      if (id === activeThreadId) {
        const next = rows[0];
        if (next) navigate({ to: "/chat", search: { t: next.id } });
        else await newChat();
      }
    } catch (e) {
      console.error(e);
      toast.error("Couldn't delete conversation.");
    }
  };

  const clearAllHistory = async () => {
    try {
      await clearAllThreadsFn();
      setThreads([]);
      await newChat();
    } catch (e) {
      console.error(e);
      toast.error("Couldn't clear history.");
    }
  };

  const canSend = !isBusy;

  const historyGroups = useMemo(() => {
    const now = Date.now();
    const day = 24 * 60 * 60 * 1000;
    const groups: { label: string; items: ThreadRow[] }[] = [
      { label: "Today", items: [] },
      { label: "Previous 7 days", items: [] },
      { label: "Earlier", items: [] },
    ];
    for (const t of threads) {
      const age = now - new Date(t.updated_at).getTime();
      if (age < day) groups[0].items.push(t);
      else if (age < 7 * day) groups[1].items.push(t);
      else groups[2].items.push(t);
    }
    return groups.filter((g) => g.items.length > 0);
  }, [threads]);

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      {booting && (
        <div className="fixed inset-0 z-[60] flex flex-col items-center justify-center gap-4 bg-background">
          <img src={cherryLogo} alt="Cherry" className="h-16 w-16 animate-cherry-pulse" />
          <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
            Preparing your workspace
          </div>
        </div>
      )}
      <header className="sticky top-0 z-20 border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-5xl items-center justify-between gap-4 px-6 py-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() => setHistoryOpen(true)}
              title="History"
              className="text-muted-foreground hover:text-foreground"
            >
              <History className="h-4 w-4" />
            </Button>
            <div className="flex items-center gap-3">
              <img
                src={cherryLogo}
                alt="Cherry logo"
                width={36}
                height={36}
                className={`h-9 w-9 ${isBusy ? "animate-cherry-pulse" : ""}`}
              />
              <div className="leading-tight">
                <div className="text-[15px] font-semibold tracking-tight">Cherry</div>
                <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                  EXECUTIVE AI ASSISTANT
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setPricingOpen(true)}
              className="gap-1.5 text-muted-foreground hover:text-foreground"
              title="Your plan"
            >
              <Sparkles className="h-4 w-4" />
              <span className="hidden sm:inline">Plan</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={exportTranscript}
              title="Export transcript as PDF"
              className="gap-1.5 text-muted-foreground hover:text-foreground"
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">PDF</span>
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={toggleVoiceOut}
              title={voiceOut ? "Mute voice" : "Read replies aloud"}
              aria-pressed={voiceOut}
              className={voiceOut ? "text-foreground" : "text-muted-foreground hover:text-foreground"}
            >
              {voiceOut ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={newChat}
              className="gap-2 text-muted-foreground hover:text-foreground"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">New session</span>
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={handleLogout}
              title="Sign out"
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {pricingOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-background/70 backdrop-blur-sm" onClick={() => setPricingOpen(false)} aria-hidden />
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <div className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-border bg-card p-6 shadow-elegant sm:p-8">
              <button type="button" onClick={() => setPricingOpen(false)} className="absolute right-4 top-4 rounded-md p-1 text-muted-foreground transition hover:bg-accent hover:text-foreground" aria-label="Close">
                <X className="h-4 w-4" />
              </button>
              <div className="mb-6 text-center">
                <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                  <Sparkles className="h-3 w-3" />
                  Your plan
                </div>
                <h2 className="mt-4 font-serif text-3xl leading-tight sm:text-4xl">Cherry is free.</h2>
                <p className="mx-auto mt-2 max-w-md text-[13.5px] leading-6 text-muted-foreground">Every feature is included at no cost — nothing to upgrade.</p>
              </div>
              <PricingPlans
                onChoose={(plan) => {
                  toast.success(`${plan.name} — everything is included at no cost.`);
                  setPricingOpen(false);
                }}
              />
              <div className="mt-6 text-center">
                <Link to="/pricing" onClick={() => setPricingOpen(false)} className="text-[12px] text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
                  See full pricing page →
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      {historyOpen && (
        <div className="fixed inset-0 z-40">
          <div className="absolute inset-0 bg-background/70 backdrop-blur-sm" onClick={() => setHistoryOpen(false)} aria-hidden />
          <aside className="absolute inset-y-0 left-0 flex w-[88%] max-w-sm flex-col border-r border-border bg-card shadow-elegant">
            <div className="flex items-center justify-between border-b border-border px-5 py-4">
              <div>
                <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Conversations</div>
                <div className="font-serif text-lg leading-tight">History</div>
              </div>
              <Button variant="ghost" size="icon-sm" onClick={() => setHistoryOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="border-b border-border px-3 py-3">
              <Button variant="ghost" size="sm" onClick={newChat} className="w-full justify-start gap-2">
                <Plus className="h-4 w-4" />
                New session
              </Button>
            </div>
            <div className="flex-1 overflow-y-auto px-2 py-3">
              {threads.length === 0 ? (
                <p className="px-3 py-6 text-center text-[13px] text-muted-foreground">No conversations yet.</p>
              ) : (
                historyGroups.map((g) => (
                  <div key={g.label} className="mb-4">
                    <div className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">{g.label}</div>
                    <ul className="space-y-0.5">
                      {g.items.map((s) => (
                        <li key={s.id}>
                          <div className={`group flex items-center gap-1 rounded-md px-2 py-1.5 transition ${s.id === activeThreadId ? "bg-accent text-foreground" : "hover:bg-accent/60"}`}>
                            <button type="button" onClick={() => openSession(s.id)} className="min-w-0 flex-1 text-left">
                              <div className="truncate text-[13.5px] leading-5 text-foreground">{s.title}</div>
                              <div className="truncate text-[11px] text-muted-foreground">{new Date(s.updated_at).toLocaleString()}</div>
                            </button>
                            <Button variant="ghost" size="icon-sm" onClick={() => deleteSession(s.id)} title="Delete" className="opacity-0 transition group-hover:opacity-100">
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))
              )}
            </div>
            {threads.length > 0 && (
              <div className="border-t border-border px-3 py-3">
                <Button variant="ghost" size="sm" onClick={clearAllHistory} className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground">
                  <Trash2 className="h-4 w-4" />
                  Clear all history
                </Button>
              </div>
            )}
          </aside>
        </div>
      )}

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-6">
        <Conversation className="flex-1">
          <ConversationContent className="gap-6 px-0 py-10">
            {messages.length === 0 && !loadingMessages ? (
              <ConversationEmptyState className="items-start justify-start px-0 py-8 text-left">
                <div className="w-full space-y-10">
                  <div className="space-y-5">
                    <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                      Live · Verified facts
                    </div>
                    <h1 className="font-serif text-5xl leading-[1.05] tracking-tight text-foreground sm:text-6xl">
                      Good day.
                      <br />
                      <span className="italic text-muted-foreground">How may I assist?</span>
                    </h1>
                    <p className="max-w-xl text-[15px] leading-7 text-muted-foreground">
                      Cherry answers with the precision of a chief of staff — grounded, concise, and decisive. Ask for strategy, drafts, analysis, or code. Attach documents for context.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
                    {CAPABILITIES.map((c) => (
                      <button key={c.label} type="button" onClick={() => sendPrompt(c.prompt)} className="group flex flex-col gap-2 bg-card p-5 text-left transition hover:bg-accent">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">{c.label}</span>
                          <ArrowUpRight className="h-4 w-4 text-muted-foreground transition group-hover:text-foreground" />
                        </div>
                        <span className="text-[14px] leading-6 text-foreground">{c.prompt}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </ConversationEmptyState>
            ) : (
              messages.map((m: UIMessage) => {
                const attachments = m.parts.filter((p) => p.type === "file") as Array<{ type: "file"; mediaType?: string; filename?: string; url?: string }>;
                const textParts = m.parts.filter((p) => p.type === "text");
                return (
                  <Message key={m.id} from={m.role} className="max-w-full">
                    {m.role === "user" ? (
                      <div className="ml-auto flex max-w-[85%] flex-col items-end gap-2">
                        {attachments.length > 0 && (
                          <div className="flex flex-wrap justify-end gap-1.5">
                            {attachments.map((a, i) => (
                              <span key={i} className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-2 py-1 text-[11.5px] text-foreground">
                                <Paperclip className="h-3 w-3 text-muted-foreground" />
                                {a.filename ?? "file"}
                              </span>
                            ))}
                          </div>
                        )}
                        {textParts.length > 0 && (
                          <MessageContent className="max-w-full rounded-2xl rounded-br-sm bg-primary px-4 py-3 text-[14.5px] leading-6 text-primary-foreground">
                            {textParts.map((p, i) => (p.type === "text" ? <span key={i}>{p.text}</span> : null))}
                          </MessageContent>
                        )}
                      </div>
                    ) : (
                      <div className="flex w-full gap-4">
                        <img src={cherryLogo} alt="Cherry" width={32} height={32} loading="lazy" className="mt-1 h-8 w-8 shrink-0 rounded-md border border-border bg-card p-1" />
                        <div className="min-w-0 flex-1 pt-1">
                          <div className="mb-1 flex items-center gap-2">
                            <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Cherry</div>
                            {groundingByMsgId[m.id]?.used && (
                              <span className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-primary">
                                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                                Web-grounded
                              </span>
                            )}
                          </div>
                          <MessageContent className="min-w-0 max-w-none border-0 bg-transparent p-0 text-[15px] leading-7 text-foreground">
                            {m.parts.map((p, i) => (p.type === "text" ? <MessageResponse key={i}>{p.text}</MessageResponse> : null))}
                          </MessageContent>
                          {groundingByMsgId[m.id]?.sources?.length ? (
                            <div className="mt-3 rounded-lg border border-border bg-card/60 p-3">
                              <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                                Sources
                              </div>
                              <ul className="space-y-1">
                                {groundingByMsgId[m.id].sources.map((s, i) => (
                                  <li key={i} className="truncate text-[12.5px] leading-5">
                                    <a
                                      href={s.url}
                                      target="_blank"
                                      rel="noreferrer noopener"
                                      className="text-primary underline-offset-2 hover:underline"
                                      title={s.url}
                                    >
                                      {s.title}
                                    </a>
                                    <span className="ml-2 text-[10px] uppercase tracking-wider text-muted-foreground">
                                      {s.provider}
                                    </span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ) : null}
                        </div>
                      </div>
                    )}
                  </Message>
                );
              })
            )}

            {status === "submitted" && (
              <Message from="assistant" className="max-w-full">
                <div className="flex w-full gap-4">
                  <img src={cherryLogo} alt="Cherry thinking" width={32} height={32} loading="lazy" className="mt-1 h-8 w-8 shrink-0 rounded-md border border-border bg-card p-1 animate-cherry-pulse" />
                  <div className="pt-1">
                    <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Cherry</div>
                    <Shimmer>Thinking…</Shimmer>
                  </div>
                </div>
              </Message>
            )}
          </ConversationContent>
          <ConversationScrollButton />
        </Conversation>

        <div
          className="sticky bottom-0 bg-gradient-to-t from-background via-background to-transparent pb-6 pt-4"
          onDragEnter={(e) => {
            if (e.dataTransfer?.types?.includes("Files")) setDragging(true);
          }}
          onDragOver={(e) => {
            if (e.dataTransfer?.types?.includes("Files")) {
              e.preventDefault();
              setDragging(true);
            }
          }}
          onDragLeave={(e) => {
            if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragging(false);
          }}
          onDrop={() => setDragging(false)}
        >
          {dragging && (
            <div className="pointer-events-none mb-2 rounded-2xl border-2 border-dashed border-primary/60 bg-primary/5 px-4 py-3 text-center text-[13px] text-primary">
              Drop text files to attach — .txt, .md, .csv, .tsv, .json (max 5, 5 MB each)
            </div>
          )}
          <ScanSummary
            files={scanFiles}
            notes={scanNotes}
            onNotesChange={setScanNotes}
            onRescan={() => {
              setScanNonce((n) => n + 1);
              setScanNotes(null);
              toast.success("Files re-scanned.");
            }}
          />
          <PromptInput
            onSubmit={handleSubmit}
            accept={ACCEPT}
            maxFiles={5}
            maxFileSize={MAX_FILE_BYTES}
            multiple
            onError={(err) => {
              if (err.code === "max_file_size") {
                toast.error(`Each file must be ${MAX_FILE_MB} MB or smaller — that upload was rejected.`);
              } else if (err.code === "max_files") {
                toast.error("You can attach up to 5 files per message.");
              } else if (err.code === "accept") {
                toast.error("Only text files are supported — use .txt, .md, .csv, .tsv or .json.");
              } else {
                toast.error(err.message);
              }
            }}
            className="overflow-hidden rounded-2xl border border-border bg-card shadow-elegant"
          >

            <AttachmentWatcher onChange={setPending} />
            <AttachmentPreviews upload={upload} onRetry={retryUpload} />
            <PromptInputBody>
              <PromptInputTextarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Brief Cherry — strategy, draft, analysis, or code…"
                autoFocus
                className="min-h-14 text-[15px] leading-7"
              />
            </PromptInputBody>
            <PromptInputFooter className="justify-between border-t border-border/60 bg-card px-3 py-2">
              <div className="flex items-center gap-1">
                <AttachButton />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon-sm"
                  onClick={toggleMic}
                  aria-pressed={listening}
                  title={listening ? "Stop listening" : "Dictate (beta)"}
                  className={listening ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}
                >
                  {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </Button>
                <span className="rounded-full border border-border px-1.5 py-0.5 text-[9.5px] font-semibold uppercase tracking-wider text-muted-foreground">
                  Voice beta
                </span>
              </div>
              <Button
                type={isBusy ? "button" : "submit"}
                size="sm"
                onClick={isBusy ? () => stop() : undefined}
                disabled={!isBusy && !canSend}
                className="h-9 gap-1.5 rounded-lg bg-primary px-4 text-[13px] font-medium text-primary-foreground hover:bg-primary/90"
              >
                {isBusy ? (
                  <>
                    <Square className="h-3.5 w-3.5 fill-current" />
                    Stop
                  </>
                ) : (
                  <>
                    Send
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </>
                )}
              </Button>
            </PromptInputFooter>
          </PromptInput>
          <p className="mt-3 text-center text-[11px] tracking-wide text-muted-foreground">
            {listening
              ? "Listening — speak clearly."
              : "Attach text files only (.txt, .md, .csv, .tsv, .json). Cherry scans them and verifies live facts."}
          </p>
        </div>
      </main>
    </div>
  );
}
