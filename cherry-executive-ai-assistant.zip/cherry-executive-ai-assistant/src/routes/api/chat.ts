import "@tanstack/react-start";
import { createFileRoute } from "@tanstack/react-router";
import {
  convertToModelMessages,
  streamText,
  type UIMessage,
  type TextUIPart,
} from "ai";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway";
import { buildLiveFactContext } from "@/lib/live-facts.server";
import { buildWebSearchGrounding } from "@/lib/web-search.server";
import type { Database } from "@/integrations/supabase/types";

// --- Simple circuit breaker for the AI gateway ---------------------------
const BREAKER = { failures: 0, openUntil: 0 };
const BREAKER_THRESHOLD = 4;         // consecutive failures before we trip
const BREAKER_COOLDOWN_MS = 60_000;  // stay open for 60s
function breakerIsOpen() {
  return Date.now() < BREAKER.openUntil;
}
function breakerRecordSuccess() {
  BREAKER.failures = 0;
  BREAKER.openUntil = 0;
}
function breakerRecordFailure() {
  BREAKER.failures += 1;
  if (BREAKER.failures >= BREAKER_THRESHOLD) {
    BREAKER.openUntil = Date.now() + BREAKER_COOLDOWN_MS;
  }
}
import {
  decodeDataUrl,
  extractTextFromFile,
  isImage,
  isPdf,
} from "@/lib/file-extract.server";

const MAX_MESSAGES = 60;
const MAX_TEXT_LEN = 40_000;
const MAX_BODY_BYTES = 25 * 1024 * 1024; // 25 MB total (files inline)

const partSchema = z.looseObject({
  type: z.string().max(64),
});

const messageSchema = z.object({
  id: z.string().max(128).optional(),
  role: z.enum(["user", "assistant"]),
  parts: z.array(partSchema).max(64).optional(),
  content: z.string().max(MAX_TEXT_LEN).optional(),
});

const bodySchema = z.object({
  messages: z.array(messageSchema).min(1).max(MAX_MESSAGES),
  threadId: z.string().uuid().optional(),
  useFallback: z.boolean().optional(),
});

// Simple trace-id + structured logger
function newTraceId(): string {
  return "trc_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}
function tlog(traceId: string, event: string, extra: Record<string, unknown> = {}) {
  try {
    console.log(JSON.stringify({ ts: new Date().toISOString(), traceId, event, ...extra }));
  } catch {
    console.log(`[${traceId}] ${event}`);
  }
}


export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const traceId = newTraceId();
        const startedAt = Date.now();
        tlog(traceId, "request.received", { url: request.url });

        const raw = await request.text();
        if (raw.length > MAX_BODY_BYTES) {
          tlog(traceId, "request.rejected", { reason: "payload_too_large", bytes: raw.length });
          return new Response("Payload too large", { status: 413, headers: { "X-Trace-Id": traceId } });
        }
        let parsedJson: unknown;
        try {
          parsedJson = JSON.parse(raw);
        } catch {
          tlog(traceId, "request.rejected", { reason: "invalid_json" });
          return new Response("Invalid JSON", { status: 400, headers: { "X-Trace-Id": traceId } });
        }
        const parsed = bodySchema.safeParse(parsedJson);
        if (!parsed.success) {
          tlog(traceId, "request.rejected", { reason: "invalid_payload", issues: parsed.error.issues });
          return new Response(
            JSON.stringify({ error: "Invalid request payload", traceId, issues: parsed.error.issues }),
            { status: 400, headers: { "Content-Type": "application/json", "X-Trace-Id": traceId } },
          );
        }
        const { messages, threadId, useFallback } = parsed.data;
        tlog(traceId, "request.parsed", {
          messageCount: messages.length,
          threadId: threadId ?? null,
          useFallback: Boolean(useFallback),
        });

        // --- Auth ---
        const authHeader = request.headers.get("authorization") ?? "";
        const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
        const SUPABASE_URL = process.env.SUPABASE_URL!;
        const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY!;
        let userId: string | null = null;
        let userSupabase: ReturnType<typeof createClient<Database>> | null = null;
        if (token) {
          userSupabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
            global: { headers: { Authorization: `Bearer ${token}` } },
            auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
          });
          const { data } = await userSupabase.auth.getClaims(token);
          userId = data?.claims?.sub ?? null;
        }
        tlog(traceId, "auth.resolved", { userId: userId ?? null });
        if (!userId || !userSupabase) {
          return new Response(
            JSON.stringify({ error: "Please sign in to chat with Cherry.", traceId }),
            { status: 401, headers: { "Content-Type": "application/json", "X-Trace-Id": traceId } },
          );
        }

        // --- Trust boundary: never accept caller-supplied "assistant" messages ---
        // When a threadId is given, rebuild prior history from the server-side
        // database (chat_messages) and take only the latest user message from
        // the request. Without a threadId, drop every non-user message.
        type ChatMessage = z.infer<typeof messageSchema>;
        let trustedMessages: ChatMessage[] = messages.filter((m) => m.role === "user");
        if (threadId) {
          const { data: historyRows } = await userSupabase
            .from("chat_messages")
            .select("role, parts, created_at")
            .eq("thread_id", threadId)
            .eq("user_id", userId)
            .order("created_at", { ascending: true })
            .limit(MAX_MESSAGES);
          const dbHistory: ChatMessage[] = (historyRows ?? [])
            .filter((r) => r.role === "user" || r.role === "assistant")
            .map((r) => ({
              role: r.role as "user" | "assistant",
              parts: (r.parts ?? []) as ChatMessage["parts"],
            }));
          const latestUser = trustedMessages[trustedMessages.length - 1];
          trustedMessages = latestUser ? [...dbHistory, latestUser] : dbHistory;
        }
        if (trustedMessages.length === 0) {
          return new Response(
            JSON.stringify({ error: "A user message is required.", traceId }),
            { status: 400, headers: { "Content-Type": "application/json", "X-Trace-Id": traceId } },
          );
        }

        // --- Preprocess file parts: extract text from docs, keep images/pdfs multimodal ---
        const typedMessages = trustedMessages as unknown as UIMessage[];
        const processed: UIMessage[] = [];
        for (const m of typedMessages) {
          if (m.role !== "user" || !m.parts) {
            processed.push(m);
            continue;
          }
          const newParts: UIMessage["parts"] = [];
          const attachmentNotes: string[] = [];
          for (const p of m.parts) {
            const anyP = p as unknown as { type: string; url?: string; mediaType?: string; filename?: string; name?: string };
            if (anyP.type === "file" && typeof anyP.url === "string") {
              const mime = anyP.mediaType ?? "application/octet-stream";
              const name = anyP.filename ?? anyP.name ?? "file";
              if (isImage(mime, name) || isPdf(mime, name)) {
                newParts.push({
                  type: "text",
                  text: `[Attachment "${name}" was rejected: Cherry only reads text files (.txt, .md, .csv, .tsv, .json).]`,
                } as TextUIPart);
                continue;
              }

              const decoded = decodeDataUrl(anyP.url);
              if (!decoded) continue;
              const text = await extractTextFromFile(mime, name, decoded.bytes).catch(() => "");
              if (text) {
                const clipped = text.length > MAX_TEXT_LEN ? text.slice(0, MAX_TEXT_LEN) + "\n[…truncated]" : text;
                newParts.push({
                  type: "text",
                  text: `--- Attached file: ${name} ---\n${clipped}\n--- end ${name} ---`,
                } as TextUIPart);
                attachmentNotes.push(`📎 ${name}`);
              }
            } else {
              newParts.push(p);
            }
          }
          processed.push({ ...m, parts: newParts });
          (m as UIMessage & { _attachmentNames?: string[] })._attachmentNames = attachmentNotes;
        }

        const geminiKey = process.env.GEMINI_API_KEY;
        const lovableKey = process.env.LOVABLE_API_KEY;
        if (!geminiKey && !lovableKey) {
          tlog(traceId, "config.error", { reason: "missing_api_key" });
          return new Response(
            JSON.stringify({ error: "Cherry isn't authorized: no LOVABLE_API_KEY or GEMINI_API_KEY.", traceId }),
            { status: 500, headers: { "Content-Type": "application/json", "X-Trace-Id": traceId } },
          );
        }

        // --- Circuit breaker: fail fast if gateway is unhealthy ---
        if (breakerIsOpen() && !useFallback && !geminiKey) {
          tlog(traceId, "breaker.open.reject", { until: BREAKER.openUntil });
          return new Response(
            JSON.stringify({
              error: "Cherry's AI service is temporarily unavailable. Please retry in a minute.",
              traceId,
              retryAfterMs: Math.max(0, BREAKER.openUntil - Date.now()),
            }),
            {
              status: 503,
              headers: {
                "Content-Type": "application/json",
                "Retry-After": "60",
                "X-Trace-Id": traceId,
                "X-Circuit-Breaker": "open",
              },
            },
          );
        }

        // --- Model selection: primary + fallback chain ---
        const lovableProvider = lovableKey ? createLovableAiGatewayProvider(lovableKey) : null;
        const geminiProvider = geminiKey
          ? createOpenAICompatible({
              name: "google-gemini",
              baseURL: "https://generativelanguage.googleapis.com/v1beta/openai",
              headers: { Authorization: `Bearer ${geminiKey}` },
            })
          : null;

        // If the breaker is open, prefer the direct-google fallback (bypasses gateway).
        const forceFallback = useFallback || breakerIsOpen();
        const primaryId = forceFallback ? "google/gemini-2.5-flash-lite" : "google/gemini-3-flash-preview";
        const useDirectGoogle = (forceFallback && geminiProvider) || !lovableProvider;
        const model = useDirectGoogle
          ? geminiProvider!.chatModel("gemini-2.0-flash")
          : lovableProvider!.chatModel(primaryId);
        tlog(traceId, "model.selected", {
          provider: useDirectGoogle ? "google-direct" : "lovable",
          model: useDirectGoogle ? "gemini-2.0-flash" : primaryId,
          breakerOpen: breakerIsOpen(),
        });

        // --- Grounding: live fact check + cached web search ---
        const groundingStart = Date.now();
        const [liveFactContext, webGrounding] = await Promise.all([
          buildLiveFactContext(processed).catch(() => ""),
          buildWebSearchGrounding(processed).catch(() => ({ context: "", sources: [] as { title: string; url: string; provider: string }[] })),
        ]);
        const webSearchContext = webGrounding.context;
        const webSources = webGrounding.sources;
        tlog(traceId, "grounding.done", {
          liveFactChars: liveFactContext.length,
          webSearchChars: webSearchContext.length,
          sourceCount: webSources.length,
          ms: Date.now() - groundingStart,
        });


        const today = new Date().toLocaleDateString("en-US", {
          weekday: "long", year: "numeric", month: "long", day: "numeric",
        });

        // --- Persist the latest user message before streaming ---
        const lastMsg = typedMessages[typedMessages.length - 1];
        if (userId && threadId && userSupabase && lastMsg?.role === "user" && !useFallback) {
          const storedParts = (lastMsg.parts ?? []).map((p) => {
            const anyP = p as unknown as { type: string; url?: string; mediaType?: string; filename?: string; name?: string; text?: string };
            if (anyP.type === "file") {
              return { type: "file", mediaType: anyP.mediaType, filename: anyP.filename ?? anyP.name, url: "" };
            }
            return p;
          });
          await userSupabase.from("chat_messages").insert({
            thread_id: threadId, user_id: userId, role: "user", parts: storedParts as never,
          });
          const firstText = (lastMsg.parts ?? []).find((p) => (p as { type: string }).type === "text") as TextUIPart | undefined;
          const titleCandidate = firstText?.text?.trim().slice(0, 80);
          const { data: t } = await userSupabase
            .from("chat_threads").select("title").eq("id", threadId).maybeSingle();
          const patch: { updated_at: string; title?: string } = { updated_at: new Date().toISOString() };
          if (t && (t.title === "New chat" || !t.title) && titleCandidate) {
            patch.title = titleCandidate.length > 60 ? titleCandidate.slice(0, 57) + "…" : titleCandidate;
          }
          await userSupabase.from("chat_threads").update(patch).eq("id", threadId);
        }

        try {
          const result = streamText({
            model,
            maxOutputTokens: 8192,
            temperature: 0.4,
            // Built-in exponential backoff for 429 / 5xx (retries: 250ms, 500ms, 1s, 2s)
            maxRetries: 4,
            system:
              `You are Cherry Executive AI Assistant — a precise, professional, current general-purpose AI assistant. Speak with the calm clarity and conviction of a world-class executive communicator. ` +
              `Today's date is ${today}. Reason with this as the current date for time-sensitive questions. ` +
              `FILE SCANNING: Cherry accepts text files only. When a message contains attached file text, first scan it and open your reply with a short "Scanned <filename>" summary — what the file is, its size/structure, and 2-4 key findings — then answer the user's question using that content. Reference every attachment by name. If an attachment was rejected, say so plainly and ask for a text file. ` +
              `FORMATTING RULES: Output clean Markdown. Use **bold** for key terms, real bullet/numbered lists, fenced code blocks with language tags. Never leave stray * or ** in the middle of sentences. No ALL-CAPS emphasis. Close every emphasis marker on the same line.` +
              liveFactContext +
              webSearchContext,
            messages: await convertToModelMessages(processed),
            onError: ({ error }) => {
              breakerRecordFailure();
              tlog(traceId, "stream.error", {
                model: primaryId,
                breakerFailures: BREAKER.failures,
                breakerOpen: breakerIsOpen(),
                message: error instanceof Error ? error.message : String(error),
              });
            },
          });

          // Encode grounding sources for the client UI (base64 JSON, safe for HTTP headers).
          const groundingPayload = webSources.length > 0 ? {
            used: true,
            sources: webSources.slice(0, 6),
          } : { used: false, sources: [] };
          const groundingHeader = Buffer.from(JSON.stringify(groundingPayload), "utf-8").toString("base64");

          const response = result.toUIMessageStreamResponse({
            originalMessages: typedMessages,
            onFinish: async ({ messages: finalMessages }) => {
              breakerRecordSuccess();
              tlog(traceId, "stream.finished", { ms: Date.now() - startedAt });
              if (!userId || !threadId || !userSupabase) return;
              const last = finalMessages[finalMessages.length - 1];
              if (!last || last.role !== "assistant") return;
              try {
                const partsWithGrounding = webSources.length > 0
                  ? [...(last.parts ?? []), { type: "data-grounding", data: groundingPayload } as never]
                  : (last.parts ?? []);
                await userSupabase.from("chat_messages").insert({
                  thread_id: threadId, user_id: userId, role: "assistant",
                  parts: partsWithGrounding as never,
                });
                await userSupabase.from("chat_threads")
                  .update({ updated_at: new Date().toISOString() }).eq("id", threadId);
              } catch (e) {
                tlog(traceId, "persist.error", { message: e instanceof Error ? e.message : String(e) });
              }
            },
            headers: {
              "X-Trace-Id": traceId,
              "X-Grounding": groundingHeader,
              "Access-Control-Expose-Headers": "X-Trace-Id, X-Grounding, X-Circuit-Breaker",
            },
          });
          return response;
        } catch (error) {
          breakerRecordFailure();
          const message = error instanceof Error ? error.message : String(error);
          tlog(traceId, "handler.error", { message, breakerFailures: BREAKER.failures, breakerOpen: breakerIsOpen() });

          // Surface rate limit / quota conditions with their own status codes so
          // the UI can show actionable guidance instead of a generic wait state.
          const rateLimited = /429|rate limit|too many requests/i.test(message);
          const quotaExhausted = /402|quota|insufficient|credit|billing|payment required/i.test(message);
          const status = rateLimited ? 429 : quotaExhausted ? 402 : breakerIsOpen() ? 503 : 500;
          const errorText = rateLimited
            ? "Rate limit reached — too many requests in a short window. Wait about a minute and try again."
            : quotaExhausted
              ? "AI usage quota exhausted. Add credits or upgrade your plan to keep chatting."
              : breakerIsOpen()
                ? "Cherry's AI service is temporarily unavailable. Please retry in a minute."
                : "AI service temporarily unavailable. Please try again.";

          return new Response(
            JSON.stringify({ error: errorText, traceId }),
            {
              status,
              headers: {
                "Content-Type": "application/json",
                "X-Trace-Id": traceId,
                ...(rateLimited ? { "Retry-After": "60" } : {}),
                ...(breakerIsOpen() ? { "X-Circuit-Breaker": "open", "Retry-After": "60" } : {}),
              },
            },
          );

        }
      },


    },
  },
});
