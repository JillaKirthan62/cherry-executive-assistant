import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import cherryLogo from "@/assets/cherry-logo.png";

export const Route = createFileRoute("/auth")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Sign in to Cherry — Executive AI Assistant" },
      {
        name: "description",
        content:
          "Continue to Cherry with Google or GitHub — no passwords to remember, secure sessions by default.",
      },
      { property: "og:title", content: "Sign in — Cherry" },
      { property: "og:description", content: "Secure access to your Cherry executive assistant." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/chat", replace: true });
    });
  }, [navigate]);

  const handleGoogle = async () => {
    setBusy("google");
    const res = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (res.error) {
      toast.error("Google sign-in failed. Please try again.");
      setBusy(null);
      return;
    }
    if (res.redirected) return;
    navigate({ to: "/chat", replace: true });
  };

  const handleGithub = async () => {
    setBusy("github");
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "github",
      options: { redirectTo: window.location.origin },
    });
    if (error) {
      toast.error(
        /provider/i.test(error.message)
          ? "GitHub sign-in isn't enabled for this workspace yet — please continue with Google."
          : error.message,
      );
      setBusy(null);
    }
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4 py-12">
      <Link to="/" className="mb-8 flex flex-col items-center gap-3">
        <img src={cherryLogo} alt="Cherry" className="h-16 w-16" />
        <div className="text-center">
          <div className="font-serif text-2xl tracking-tight">Cherry</div>
          <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            Executive AI Assistant
          </div>
        </div>
      </Link>

      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-elegant sm:p-8">
        <h1 className="font-serif text-xl">Continue to Cherry</h1>
        <p className="mt-1 text-[13px] leading-6 text-muted-foreground">
          One tap, no passwords. Your session stays secure and private.
        </p>

        <div className="mt-6 space-y-3">
          <Button
            type="button"
            className="w-full"
            onClick={handleGoogle}
            disabled={busy !== null}
          >
            {busy === "google" ? "Opening Google…" : "Continue with Google"}
          </Button>
          <Button
            type="button"
            variant="outline"
            className="w-full gap-2"
            onClick={handleGithub}
            disabled={busy !== null}
          >
            <svg viewBox="0 0 16 16" aria-hidden className="h-4 w-4 fill-current"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.88.51-1.08-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.07-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82a7.4 7.4 0 0 1 2-.27c.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.15 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.94-.01 2.21 0 .21.15.46.55.38A7.99 7.99 0 0 0 16 8c0-4.42-3.58-8-8-8Z"/></svg>
            {busy === "github" ? "Opening GitHub…" : "Continue with GitHub"}
          </Button>
        </div>

        <p className="mt-6 text-center text-[12px] leading-5 text-muted-foreground">
          By continuing you agree to use Cherry responsibly. Accounts are created
          automatically on first sign-in.
        </p>
      </div>
    </div>
  );
}
