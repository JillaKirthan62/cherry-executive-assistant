import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  FileText,
  Globe2,
  LogOut,
  Mic,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import cherryLogo from "@/assets/cherry-logo.png";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Cherry — Executive AI Assistant for Serious Work" },
      {
        name: "description",
        content:
          "Cherry is an executive-grade AI assistant: verified answers, document analysis, voice input and secure private chat history. Start free.",
      },
      { property: "og:title", content: "Cherry — Executive AI Assistant" },
      {
        property: "og:description",
        content:
          "Verified answers, document analysis, voice input and private chat history. Start free.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

const FEATURES = [
  {
    icon: Globe2,
    title: "Live-verified answers",
    body: "Cherry checks current facts against authoritative sources before answering, and shows you the sources it used.",
  },
  {
    icon: FileText,
    title: "Document intelligence",
    body: "Attach text files (.txt, .md, .csv, .tsv, .json). Cherry scans them, summarises what it found, and answers in context.",
  },
  {
    icon: Mic,
    title: "Voice input (beta)",
    body: "Dictate your brief and have replies read back to you, hands-free, straight in the browser.",
  },
  {
    icon: ShieldCheck,
    title: "Private by default",
    body: "Email-verified accounts, strict password rules and row-level isolation so your conversations stay yours.",
  },
  {
    icon: Zap,
    title: "Resilient streaming",
    body: "Token-by-token replies with automatic retries and a backup model if the primary is busy.",
  },
  {
    icon: Sparkles,
    title: "Executive tone",
    body: "Clear, decisive briefings written the way a chief of staff would write them. No filler.",
  },
];

const STEPS = [
  { n: "01", t: "Create your account", d: "Name, email and a strong password. Verify your email and you're in." },
  { n: "02", t: "Brief Cherry", d: "Type, dictate or drop a document into the composer." },
  { n: "03", t: "Act on the answer", d: "Get a grounded reply with sources, then export the transcript." },
];

function LandingPage() {
  const navigate = useNavigate();
  const [signedIn, setSignedIn] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSignedIn(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) =>
      setSignedIn(!!session),
    );
    return () => sub.subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setSignedIn(false);
    navigate({ to: "/" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <img src={cherryLogo} alt="Cherry logo" width={34} height={34} className="h-[34px] w-[34px]" />
            <div className="leading-tight">
              <div className="text-[15px] font-semibold tracking-tight">Cherry</div>
              <div className="text-[10.5px] uppercase tracking-[0.18em] text-muted-foreground">
                Executive AI Assistant
              </div>
            </div>
          </div>
          <nav className="flex items-center gap-1">
            <Link
              to="/pricing"
              className="hidden rounded-md px-3 py-2 text-[13px] text-muted-foreground transition hover:text-foreground sm:block"
            >
              Pricing
            </Link>
            {signedIn ? (
              <>
                <Button asChild size="sm" className="gap-1.5">
                  <Link to="/chat">
                    Open Cherry
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </Link>
                </Button>
                <Button variant="ghost" size="sm" onClick={signOut} className="gap-1.5 text-muted-foreground">
                  <LogOut className="h-4 w-4" />
                  <span className="hidden sm:inline">Log out</span>
                </Button>
              </>
            ) : (
              <>
                <Button asChild variant="ghost" size="sm">
                  <Link to="/auth">Sign in</Link>
                </Button>
                <Button asChild size="sm" className="gap-1.5">
                  <Link to="/auth">
                    Get started
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </Link>
                </Button>
              </>
            )}
          </nav>
        </div>
      </header>

      <main>
        <section className="border-b border-border">
          <div className="mx-auto grid w-full max-w-6xl gap-12 px-6 py-20 lg:grid-cols-[1.1fr_0.9fr] lg:py-28">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Live · Verified facts
              </div>
              <h1 className="mt-6 font-serif text-5xl leading-[1.03] tracking-tight sm:text-6xl lg:text-7xl">
                The assistant that
                <br />
                <span className="italic text-muted-foreground">briefs like a chief of staff.</span>
              </h1>
              <p className="mt-6 max-w-xl text-[16px] leading-8 text-muted-foreground">
                Cherry answers with precision — grounded in live sources, aware of your documents,
                and ready for voice. Built for people whose decisions carry weight.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-3">
                <Button asChild size="lg" className="gap-2">
                  <Link to={signedIn ? "/chat" : "/auth"} search={signedIn ? undefined : { mode: "signup" }}>
                    {signedIn ? "Open Cherry" : "Start free"}
                    <ArrowUpRight className="h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link to="/pricing">See what's included</Link>
                </Button>
              </div>
              <p className="mt-4 text-[12px] text-muted-foreground">
                No credit card required. Email verification keeps your account secure.
              </p>
            </div>

            <div className="relative">
              <div className="rounded-2xl border border-border bg-card p-5 shadow-elegant">
                <div className="flex items-center gap-2 border-b border-border pb-3">
                  <span className="h-2.5 w-2.5 rounded-full bg-primary/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-border" />
                  <span className="h-2.5 w-2.5 rounded-full bg-border" />
                  <span className="ml-2 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                    Cherry session
                  </span>
                </div>
                <div className="space-y-4 pt-4">
                  <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-sm bg-primary px-4 py-2.5 text-[13.5px] text-primary-foreground">
                    Summarise this board deck and flag the three biggest risks.
                  </div>
                  <div className="flex gap-3">
                    <img src={cherryLogo} alt="" width={26} height={26} className="mt-0.5 h-[26px] w-[26px] rounded-md border border-border p-1" />
                    <div className="space-y-2 text-[13.5px] leading-6 text-foreground">
                      <p>Three risks stand out, in order of exposure:</p>
                      <p className="text-muted-foreground">
                        1. Q4 revenue concentration in a single account. 2. Hiring plan outpacing runway by
                        two months. 3. No signed DPA with the new vendor.
                      </p>
                      <div className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-primary">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                        Web-grounded
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-6xl px-6 py-20">
            <h2 className="font-serif text-3xl tracking-tight sm:text-4xl">Everything you need in one composer.</h2>
            <p className="mt-3 max-w-2xl text-[15px] leading-7 text-muted-foreground">
              Cherry is not a demo. It streams, remembers, reads your files and cites its work.
            </p>
            <div className="mt-10 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f) => (
                <div key={f.title} className="bg-card p-6">
                  <f.icon className="h-5 w-5 text-primary" />
                  <h3 className="mt-4 text-[15px] font-semibold tracking-tight">{f.title}</h3>
                  <p className="mt-2 text-[13.5px] leading-6 text-muted-foreground">{f.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-6xl px-6 py-20">
            <h2 className="font-serif text-3xl tracking-tight sm:text-4xl">Up and running in a minute.</h2>
            <div className="mt-10 grid gap-8 sm:grid-cols-3">
              {STEPS.map((s) => (
                <div key={s.n}>
                  <div className="font-serif text-4xl text-primary">{s.n}</div>
                  <h3 className="mt-3 text-[15px] font-semibold tracking-tight">{s.t}</h3>
                  <p className="mt-2 text-[13.5px] leading-6 text-muted-foreground">{s.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section>
          <div className="mx-auto w-full max-w-3xl px-6 py-24 text-center">
            <h2 className="font-serif text-4xl leading-tight tracking-tight sm:text-5xl">
              Bring Cherry into your next decision.
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-[15px] leading-7 text-muted-foreground">
              Create an account, verify your email and start briefing in seconds.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Button asChild size="lg" className="gap-2">
                <Link to={signedIn ? "/chat" : "/auth"} search={signedIn ? undefined : { mode: "signup" }}>
                  {signedIn ? "Open Cherry" : "Create your account"}
                  <ArrowUpRight className="h-4 w-4" />
                </Link>
              </Button>
              {!signedIn && (
                <Button asChild size="lg" variant="outline">
                  <Link to="/auth">Sign in</Link>
                </Button>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-3 px-6 py-8 text-[12px] text-muted-foreground sm:flex-row">
          <span>Cherry Executive AI Assistant — Design by Jilla Kirthan</span>
          <div className="flex items-center gap-4">
            <Link to="/pricing" className="hover:text-foreground">Pricing</Link>
            <Link to="/auth" className="hover:text-foreground">Sign in</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
