# Run Cherry Executive AI Assistant on your computer

1. Install Node.js 20+ and Bun (https://bun.sh).
2. In this folder run: `bun install`
3. Copy `.env.example` to `.env` and paste your Google Gemini key after `GEMINI_API_KEY=`.
4. Start: `bun run dev` then open http://localhost:8080
5. Production build: `bun run build` (output in `dist/`), preview with `bun run preview`.

Sign-in and chat history use the existing Lovable Cloud backend (public keys already in `.env.example`).
For Google sign-in on localhost, sign in on the published site or add your local URL to allowed redirects.
